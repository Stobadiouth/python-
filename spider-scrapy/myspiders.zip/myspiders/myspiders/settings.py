# -*- coding: utf-8 -*-

# Scrapy settings for myspiders project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://doc.scrapy.org/en/latest/topics/settings.html
#     https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://doc.scrapy.org/en/latest/topics/spider-middleware.html

BOT_NAME = 'myspiders'

SPIDER_MODULES = ['myspiders.spiders']
NEWSPIDER_MODULE = 'myspiders.spiders'


# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'myspiders (+http://www.yourdomain.com)'

# Obey robots.txt rules
ROBOTSTXT_OBEY = False

# Configure maximum concurrent requests performed by Scrapy (default: 16)
#CONCURRENT_REQUESTS = 32

# Configure a delay for requests for the same website (default: 0)
# See https://doc.scrapy.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs
DOWNLOAD_DELAY = 1
# The download delay setting will honor only one of:
#CONCURRENT_REQUESTS_PER_DOMAIN = 16
#CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
#COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
#TELNETCONSOLE_ENABLED = False

# Override the default request headers:
#DEFAULT_REQUEST_HEADERS = {
#   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
#   'Accept-Language': 'en',
#}

# Enable or disable spider middlewares
# See https://doc.scrapy.org/en/latest/topics/spider-middleware.html
#SPIDER_MIDDLEWARES = {
#    'myspiders.middlewares.MyspidersSpiderMiddleware': 543,
#}

# Enable or disable downloader middlewares
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
#DOWNLOADER_MIDDLEWARES = {
#    'myspiders.middlewares.MyspidersDownloaderMiddleware': 543,
#}

# Enable or disable extensions
# See https://doc.scrapy.org/en/latest/topics/extensions.html
#EXTENSIONS = {
#    'scrapy.extensions.telnet.TelnetConsole': None,
#}

# Configure item pipelines
# See https://doc.scrapy.org/en/latest/topics/item-pipeline.html
ITEM_PIPELINES = {
   # 'myspiders.pipelines.MyspidersPipeline': 300,
   # 'myspiders.pipelines.MiPipeline': 300,
   # 'myspiders.imagepipelines.saveImage': 400,
   # 'myspiders.Messagepipelines.MessagePipeline': 400,
   # 'myspiders.Lifepipelines.LifePipeline': 400,
   'myspiders.Hobbypipelines.HobbyPipeline': 400,
}

# Enable and configure the AutoThrottle extension (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/autothrottle.html
#AUTOTHROTTLE_ENABLED = True
# The initial download delay
#AUTOTHROTTLE_START_DELAY = 5
# The maximum download delay to be set in case of high latencies
#AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
#AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
#AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
#HTTPCACHE_ENABLED = True
#HTTPCACHE_EXPIRATION_SECS = 0
#HTTPCACHE_DIR = 'httpcache'
#HTTPCACHE_IGNORE_HTTP_CODES = []
#HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'

IMAGES_STORE = 'HNimages/'
# IMAGES_EXPIRES = 30

##过滤图片
# IMAGES_MIN_HEIGHT = 110
# IMAGES_MIN_WIDTH = 110

# IMAGES_THUMBS = {
#     'big': (270, 270),
#     'small': (80, 80)
# }
COOKIE={'11004205': '11004205', '10722194': '10722194', '10934396': '10934396', '10530369': '10530369', '10542137': '10542137', '10426999': '10426999', '10758663': '10758663', '10483884': '10483884', '10633221': '10633221', '10431768': '10431768', '10701620': '10701620', '10685906': '10685906', '10522552': '10522552', '10804625': '10804625', '10726129': '10726129', '10986619': '10986619', '10901423': '10901423', '10785559': '10785559', '10578848': '10578848', '10655776': '10655776', '10401355': '10401355', '10526024': '10526024', '10885444': '10885444', '10856095': '10856095', '10828166': '10828166', '10641080': '10641080', '10772208': '10772208', '10920274': '10920274', '10788323': '10788323', '10709382': '10709382', '10864884': '10864884', '10459570': '10459570', '10708522': '10708522', '10770582': '10770582', '10488552': '10488552', '10892142': '10892142', '10973021': '10973021', '10401738': '10401738', '10808985': '10808985', '342028': '342028', '10890235': '10890235', '10756029': '10756029', '10891288': '10891288', '10472209': '10472209', '10967638': '10967638', '10609657': '10609657', '10662188': '10662188', '10552817': '10552817', '10413304': '10413304', '10732869': '10732869', '320396': '320396', '10687415': '10687415', '10957118': '10957118', '322678': '322678', '10887248': '10887248', '10996974': '10996974', '10880389': '10880389', '347094': '347094', '10639218': '10639218', '10565292': '10565292', '10822468': '10822468', '10970148': '10970148', '10401904': '10401904', '10809882': '10809882', '10740896': '10740896', '10647603': '10647603', '10531613': '10531613', 'PHPSESSID': 'b0s6ldpl9ja8odieesm9pp0b04', '10596645': '10596645', '343150': '343150', '10716956': '10716956', '10524542': '10524542', '10685739': '10685739', '10780535': '10780535', '10425483': '10425483', '10596664': '10596664', '10622483': '10622483', '10423689': '10423689', '10655408': '10655408', '10955440': '10955440', '319304': '319304', '10535241': '10535241', '10465478': '10465478', '10545516': '10545516', '10393446': '10393446', '10514842': '10514842', '10518401': '10518401', '10455724': '10455724', '10509843': '10509843', '10731392': '10731392', '10764798': '10764798', '10785100': '10785100', '10361369': '10361369', '10754862': '10754862', '10557454': '10557454', '10698120': '10698120', '10966441': '10966441', '10522154': '10522154', '10847144': '10847144', '10950949': '10950949', '329890': '329890', '10905434': '10905434', '10563239': '10563239', '10824156': '10824156', '10623289': '10623289', '10889225': '10889225', '10871854': '10871854', '10898703': '10898703', '10771678': '10771678', '10558157': '10558157', '10903294': '10903294', '10444929': '10444929', '10742024': '10742024', '10975977': '10975977', '334175': '334175', '10863685': '10863685', '10582645': '10582645', '10475762': '10475762', '10451771': '10451771', '10482749': '10482749', '10351529': '10351529', '316587': '316587', '10888834': '10888834', '10892304': '10892304', '10925275': '10925275', '10808703': '10808703', '10485027': '10485027', '10772731': '10772731', '10867453': '10867453', '10420134': '10420134', '10970157': '10970157', '10474790': '10474790', '10716136': '10716136', '10668972': '10668972', '10493455': '10493455', '10445321': '10445321', '10571223': '10571223', '10633183': '10633183', '10867105': '10867105', '10555625': '10555625', '10925556': '10925556', '10924576': '10924576', '10922253': '10922253', '10697408': '10697408', '10901223': '10901223', '10738449': '10738449', '10494466': '10494466', '10447668': '10447668', '10646553': '10646553', '10502512': '10502512', '10897791': '10897791', '10708532': '10708532', '10844282': '10844282', '10572811': '10572811', '10927464': '10927464', '10808698': '10808698', '10967015': '10967015', '10807992': '10807992', 'Hm_lvt_13345a0835e13dfae20053e4d44560b9': '1537595381,1537873371,1537879819,1537930652', '10417670': '10417670', '10361084': '10361084', '10619329': '10619329', '10724344': '10724344', '10599253': '10599253', '10490979': '10490979', '10717261': '10717261', '10867679': '10867679', 'CwCzwf_sex_ta': '2', 'CwCzwf_prompt_tomorry': '1', 'Hm_lpvt_13345a0835e13dfae20053e4d44560b9': '1537960768', 'CwCzwf_userid': '11004091', '11004218': '11004218'}
